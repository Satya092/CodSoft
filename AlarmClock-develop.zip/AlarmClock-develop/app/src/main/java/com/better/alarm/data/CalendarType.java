package com.better.alarm.data;

public enum CalendarType {
  NORMAL,
  SNOOZE,
  PREALARM,
  AUTOSILENCE
}
